package br.com.projetoproduto.dao;

import java.util.List;

public interface GenericDAO {
    public Boolean cadastrar(Object object);
    puclic List<obejct> listar();
    public Boolean excluir(int indObject);
    public Object carregar (int indObjct);
    public Boolean alterar (Object object);
    
}
