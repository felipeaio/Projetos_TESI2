package br.com.projetoproduto.dao;

import java.util.List;

public interface GenericDAO {
    public Boolean cadastrar(Object object);
    public List <Object> listar();
    public Boolean excluir(int indObject);
    public Object carregar (int indObjct);
    public Boolean alterar (Object object);
    
}
