package br.com.projetocliente.model;

public class Cliente {

 private Integer idCliente;
 private String nomeCliente;
 private Double telefoneCliente;

    public Cliente() {
    }

    public Cliente(Integer idCliente, String nomeCliente, Double telefoneCliente) {
        this.idCliente = idCliente;
        this.nomeCliente = nomeCliente;
        this.telefoneCliente = telefoneCliente;
    }

    public Integer getIdCliente() {
        return idCliente;
    }

    public void setIdCliente(Integer idCliente) {
        this.idCliente = idCliente;
    }

    public String getNomeCliente() {
        return nomeCliente;
    }

    public void setNomeCliente(String nomeCliente) {
        this.nomeCliente = nomeCliente;
    }

    public Double getTelefoneCliente() {
        return telefoneCliente;
    }

    public void setTelefoneCliente(Double telefoneCliente) {
        this.telefoneCliente = telefoneCliente;
    }



 
}

