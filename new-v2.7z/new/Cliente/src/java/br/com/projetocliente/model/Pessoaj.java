
package br.com.projetocliente.model;

public class Pessoaj extends Cliente {
 private Integer idPessoaj;
 private String nomePessoaj;
 private Double cnpjPessoaj;
 private Pessoaj Pessoaj;

    public Pessoaj() {
    }

    public Pessoaj(Integer idPessoaj, String nomePessoaj, Double cnpjPessoaj, Pessoaj Pessoaj) {
        this.idPessoaj = idPessoaj;
        this.nomePessoaj = nomePessoaj;
        this.cnpjPessoaj = cnpjPessoaj;
        this.Pessoaj = Pessoaj;
    }

    public Pessoaj(Integer idPessoaj, String nomePessoaj, Double cnpjPessoaj, Pessoaj Pessoaj, Integer idCliente, String nomeCliente, Double telefoneCliente) {
        super(idCliente, nomeCliente, telefoneCliente);
        this.idPessoaj = idPessoaj;
        this.nomePessoaj = nomePessoaj;
        this.cnpjPessoaj = cnpjPessoaj;
        this.Pessoaj = Pessoaj;
    }

    public Integer getIdPessoaj() {
        return idPessoaj;
    }

    public void setIdPessoaj(Integer idPessoaj) {
        this.idPessoaj = idPessoaj;
    }

    public String getNomePessoaj() {
        return nomePessoaj;
    }

    public void setNomePessoaj(String nomePessoaj) {
        this.nomePessoaj = nomePessoaj;
    }

    public Double getCnpjPessoaj() {
        return cnpjPessoaj;
    }

    public void setCnpjPessoaj(Double cnpjPessoaj) {
        this.cnpjPessoaj = cnpjPessoaj;
    }

    public Pessoaj getPessoaj() {
        return Pessoaj;
    }

    public void setPessoaj(Pessoaj Pessoaj) {
        this.Pessoaj = Pessoaj;
    }
 

 
}