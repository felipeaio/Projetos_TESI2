package br.com.projetocliente.dao;

import br.com.projetocliente.util.ConnectionFactory;
import br.com.projetocliente.model.Cliente;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ClienteDAOImpl implements GenericDAO {

    private Connection conn;

    public ClienteDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
            System.out.println("Conectado com Sucesso!");
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }



    public Integer cadastrar(Cliente cliente) {

        PreparedStatement stmt = null;
        ResultSet rs = null;
        Integer idCliente = null;

        String sql = "insert into cliente(nomecliente, telefonecliente) values (?, ?) returning idcliente;";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, cliente.getNomeCliente());
            stmt.setDouble(2, cliente.getTelefoneCliente());
            rs = stmt.executeQuery();
            
            if (rs.next()){
             idCliente = rs.getInt("idcliente");
            }
        } catch (SQLException ex) {
            System.out.println("Problemas ao cadastrar cliente! Erro: " + ex.getMessage());
            ex.printStackTrace();
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar conexÃ£o! Erro" + ex.getMessage());
                ex.printStackTrace();
            }
        }
return idCliente;
    
}

    @Override
    public List<Object> listar() {

        List<Object> clientes = new ArrayList();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select * from cliente;";

        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                Cliente cliente = new Cliente();
                cliente.setIdCliente(rs.getInt("idcliente"));
                cliente.setNomeCliente(rs.getString("nomecliente"));
                cliente.setTelefoneCliente(rs.getDouble("telefonecliente"));
                clientes.add(cliente);
            }

        } catch (SQLException ex) {
            System.out.println("Problema ao listar cliente: " + ex.getMessage());
            ex.printStackTrace();

        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
        return clientes;
    }

    @Override
    public Boolean excluir(int idObject) {
        PreparedStatement stmt = null;
        String sql = "delete from cliente where idcliente = ?;";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idObject);
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problema ao excluir cliente: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
    }

    @Override
    public Object carregar(int idObject) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Cliente cliente = null;

        String sql = "select * from cliente where idcliente = ?;";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idObject);
            rs = stmt.executeQuery();

            while (rs.next()) {
                cliente = new Cliente();
                cliente.setIdCliente(rs.getInt("idcliente"));
                cliente.setNomeCliente(rs.getString("nomecliente"));
                cliente.setTelefoneCliente(rs.getDouble("doublecliente"));
            }
        } catch (SQLException ex) {
            System.out.println("Problema ao carregar cliente: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
        return cliente;
    }

    @Override
    public Boolean alterar(Object object) {

        Cliente cliente = (Cliente) object;
        PreparedStatement stmt = null;
        String sql = "update cliente set nomecliente = ?, telefonecliente = ? where idcliente = ?;";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, cliente.getNomeCliente());
            stmt.setDouble(2, cliente.getTelefoneCliente());
            stmt.setInt(3, cliente.getIdCliente());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problema ao alterar cliente: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
    }

    @Override
    public Boolean cadastrar(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}