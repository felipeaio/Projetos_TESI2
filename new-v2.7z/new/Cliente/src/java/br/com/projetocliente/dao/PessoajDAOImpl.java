package br.com.projetocliente.dao;

import br.com.projetocliente.model.Pessoaj;
import br.com.projetocliente.util.ConnectionFactory;
import br.com.projetocliente.model.Cliente;
import br.com.projetocliente.model.Categoria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PessoajDAOImpl implements GenericDAO {

    private Connection conn;

    public PessoajDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
            System.out.println("Conectado com Sucesso!");
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override

    public Boolean cadastrar(Object object) {

        Pessoaj pessoaj = (Pessoaj) object;
        PreparedStatement stmt = null;

        String sql = "insert into pessoaj(anopessoaj, modelopessoaj, nrportaspessoaj, idtipopessoaj, idcliente) values (?, ?, ?, ?, ?);";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, pessoaj.getNomePessoaj());
            stmt.setDouble(2, pessoaj.getCnpjPessoaj());
            stmt.setInt(4, pessoaj.getTipoPessoaj().getIdTipoPessoaj());
            stmt.setInt(5, new ClienteDAOImpl().cadastrar(pessoaj));
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar Pessoaj! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar conexÃ£o! Erro" + ex.getMessage());
                ex.printStackTrace();
            }
        }

    }

    @Override
    public List<Object> listar() {

        List<Object> pessoajs = new ArrayList();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select p.*, c.*, t.* from cliente p, pessoaj c, tipopessoaj t where p.idcliente = c.idcliente and c.idtipopessoaj = t.idtipopessoaj;";

        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                
                Pessoaj pessoaj = new Pessoaj();
                pessoaj.setIdCliente(rs.getInt("idcliente"));
                pessoaj.setDescCliente(rs.getString("desccliente"));
                pessoaj.setMarcaCliente(rs.getString("marcacliente"));
                pessoaj.setModeloCliente(rs.getString("modelocliente"));
                pessoaj.setPrecoCliente(rs.getDouble("precocliente"));
                pessoaj.setAnoPessoaj(rs.getInt("anopessoaj"));
                pessoaj.setModeloPessoaj(rs.getInt("modelopessoaj"));
                pessoaj.setNrportaPessoaj(rs.getInt("nrportaspessoaj"));
                pessoaj.setTipoPessoaj(new TipoPessoaj(rs.getInt("idtipopessoaj")));
                pessoaj.setTipoPessoaj(new TipoPessoaj(rs.getString("nometipopessoaj")));
                
               
                pessoajs.add(pessoaj);
            }

        } catch (SQLException ex) {
            System.out.println("Problema ao listar cliente: " + ex.getMessage());
            ex.printStackTrace();

        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
        return pessoajs;
    }

    @Override
    public Boolean excluir(int idObject) {
        PreparedStatement stmt = null;
        String sql = "delete from pessoaj using cliente where pessoaj.idcliente = cliente.idcliente and cliente.idcliente = ?;";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idObject);
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problema ao excluir cliente: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
    }

    @Override
    public Object carregar(int idObject) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Pessoaj pessoaj = new Pessoaj();

        String sql = "select p.*, c.* from cliente p, pessoaj c where p.idcliente = c.idcliente and c.idcliente = ?;";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idObject);
            rs = stmt.executeQuery();

            while (rs.next()) {
             
              
                pessoaj.setIdCliente(rs.getInt("idcliente"));
                pessoaj.setDescCliente(rs.getString("desccliente"));
                pessoaj.setMarcaCliente(rs.getString("marcacliente"));
                pessoaj.setModeloCliente(rs.getString("modelocliente"));
                pessoaj.setPrecoCliente(rs.getDouble("precocliente"));
                pessoaj.setAnoPessoaj(rs.getInt("anopessoaj"));
                pessoaj.setModeloPessoaj(rs.getInt("modelopessoaj"));
                pessoaj.setNrportaPessoaj(rs.getInt("nrportaspessoaj"));
                pessoaj.setIdPessoaj(rs.getInt("idpessoaj"));
                
            }
        } catch (SQLException ex) {
            System.out.println("Problema ao carregar cliente: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
        return pessoaj;
    }

    @Override
    public Boolean alterar(Object object) {

        Cliente cliente = (Cliente) object;
        PreparedStatement stmt = null;
        String sql = "update cliente set desccliente = ?, marcacliente = ?, modelocliente = ?, precocliente = ? where idcliente = ?;";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, cliente.getDescCliente());
            stmt.setString(2, cliente.getMarcaCliente());
            stmt.setString(3, cliente.getModeloCliente());
            stmt.setDouble(4, cliente.getPrecoCliente());
            stmt.setInt(5, cliente.getIdCliente());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problema ao alterar cliente: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
    }
}
