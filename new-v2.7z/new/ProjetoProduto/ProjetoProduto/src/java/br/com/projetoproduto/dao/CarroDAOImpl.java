package br.com.projetoproduto.dao;

import br.com.projetoproduto.model.Carro;
import br.com.projetoproduto.util.ConnectionFactory;
import br.com.projetoproduto.model.Produto;
import br.com.projetoproduto.model.TipoCarro;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class CarroDAOImpl implements GenericDAO {

    private Connection conn;

    public CarroDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
            System.out.println("Conectado com Sucesso!");
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override

    public Boolean cadastrar(Object object) {

        Carro carro = (Carro) object;
        PreparedStatement stmt = null;

        String sql = "insert into carro(anocarro, modelocarro, nrportascarro, idtipocarro, idproduto) values (?, ?, ?, ?, ?);";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, carro.getAnoCarro());
            stmt.setInt(2, carro.getModeloCarro());
            stmt.setInt(3, carro.getNrportaCarro());
            stmt.setInt(4, carro.getTipoCarro().getIdTipoCarro());
            stmt.setInt(5, new ProdutoDAOImpl().cadastrar(carro));
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar Carro! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar conexÃ£o! Erro" + ex.getMessage());
                ex.printStackTrace();
            }
        }

    }

    @Override
    public List<Object> listar() {

        List<Object> carros = new ArrayList();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select p.*, c.*, t.* from produto p, carro c, tipocarro t where p.idproduto = c.idproduto and c.idtipocarro = t.idtipocarro;";

        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                
                Carro carro = new Carro();
                carro.setIdProduto(rs.getInt("idproduto"));
                carro.setDescProduto(rs.getString("descproduto"));
                carro.setMarcaProduto(rs.getString("marcaproduto"));
                carro.setModeloProduto(rs.getString("modeloproduto"));
                carro.setPrecoProduto(rs.getDouble("precoproduto"));
                carro.setAnoCarro(rs.getInt("anocarro"));
                carro.setModeloCarro(rs.getInt("modelocarro"));
                carro.setNrportaCarro(rs.getInt("nrportascarro"));
                carro.setTipoCarro(new TipoCarro(rs.getInt("idtipocarro")));
                carro.setTipoCarro(new TipoCarro(rs.getString("nometipocarro")));
                
               
                carros.add(carro);
            }

        } catch (SQLException ex) {
            System.out.println("Problema ao listar produto: " + ex.getMessage());
            ex.printStackTrace();

        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
        return carros;
    }

    @Override
    public Boolean excluir(int idObject) {
        PreparedStatement stmt = null;
        String sql = "delete from carro using produto where carro.idproduto = produto.idproduto and produto.idproduto = ?;";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idObject);
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problema ao excluir produto: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
    }

    @Override
    public Object carregar(int idObject) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Carro carro = new Carro();

        String sql = "select p.*, c.* from produto p, carro c where p.idproduto = c.idproduto and c.idproduto = ?;";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idObject);
            rs = stmt.executeQuery();

            while (rs.next()) {
             
              
                carro.setIdProduto(rs.getInt("idproduto"));
                carro.setDescProduto(rs.getString("descproduto"));
                carro.setMarcaProduto(rs.getString("marcaproduto"));
                carro.setModeloProduto(rs.getString("modeloproduto"));
                carro.setPrecoProduto(rs.getDouble("precoproduto"));
                carro.setAnoCarro(rs.getInt("anocarro"));
                carro.setModeloCarro(rs.getInt("modelocarro"));
                carro.setNrportaCarro(rs.getInt("nrportascarro"));
                carro.setIdCarro(rs.getInt("idcarro"));
                
            }
        } catch (SQLException ex) {
            System.out.println("Problema ao carregar produto: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
        return carro;
    }

    @Override
    public Boolean alterar(Object object) {

        Produto produto = (Produto) object;
        PreparedStatement stmt = null;
        String sql = "update produto set descproduto = ?, marcaproduto = ?, modeloproduto = ?, precoproduto = ? where idproduto = ?;";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, produto.getDescProduto());
            stmt.setString(2, produto.getMarcaProduto());
            stmt.setString(3, produto.getModeloProduto());
            stmt.setDouble(4, produto.getPrecoProduto());
            stmt.setInt(5, produto.getIdProduto());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problema ao alterar produto: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
    }
}
