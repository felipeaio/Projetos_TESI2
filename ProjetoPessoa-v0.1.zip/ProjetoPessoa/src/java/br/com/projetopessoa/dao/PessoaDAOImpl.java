package br.com.projetopessoa.dao;

import br.com.projetopessoa.util.ConnectionFactory;
import br.com.projetopessoa.model.Pessoa;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.List;

public class PessoaDAOImpl implements GenericDAO{

    private Connection conn;
    
    public PessoaDAOImpl() throws Exception{
    try{
        this.conn = ConnectionFactory.getConnection();
        System.out.println("Conectado com Sucesso!");
    }catch (Exception ex){
    throw new Exception(ex.getMessage());
    }
    }
    
    @Override
    
    public Boolean cadastrar(Object object) {
        
        Pessoa pessoa = (Pessoa) object;
        PreparedStatement stmt = null;
        
        String sql = "insert into Pessoa(nomepessoa, cpfpessoa) values (?, ?);";
        
        try{
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, pessoa.getNomePessoa());
            stmt.setDouble(2, pessoa.getCpfPessoa());
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar pessoa! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            }catch (Exception ex) {
                System.out.println("Problemas ao fechar conexÃ£o! Erro" + ex.getMessage());
                ex.printStackTrace();
            }
        }
    }

    @Override
    public List<Object> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean excluir(int indObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int indObjct) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean alterar(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }
    
}