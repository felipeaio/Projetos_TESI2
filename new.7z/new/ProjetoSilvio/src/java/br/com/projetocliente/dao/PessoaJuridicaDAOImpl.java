package br.com.projetocliente.dao;

import br.com.projetocliente.model.PessoaJuridica;
import br.com.projetocliente.util.ConnectionFactory;
import br.com.projetocliente.model.Cliente;
import br.com.projetocliente.model.Categoria;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class PessoaJuridicaDAOImpl implements GenericDAO {

    private Connection conn;

    public PessoaJuridicaDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
            System.out.println("Conectado com Sucesso!");
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override

    public Boolean cadastrar(Object object) {

        PessoaJuridica pessoajuridica = (PessoaJuridica) object;
        PreparedStatement stmt = null;

        String sql = "insert into pessoaj(nomepessoaj, cnpjpessoaj, idcategoria, idcliente) values (?, ?, ?, ?);";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, pessoajuridica.getNomePessoaJuridica());
            stmt.setInt(2, pessoajuridica.getCnpjPessoaJuridica());
            stmt.setInt(3, pessoajuridica.getIdCategoria());
            stmt.setInt(4, new ClienteDAOImpl().cadastrar(pessoajuridica));
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar Pessoaj! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar conexÃ£o! Erro" + ex.getMessage());
                ex.printStackTrace();
            }
        }

    }

    @Override
    public List<Object> listar() {

        List<Object> pessoajuridicas = new ArrayList();
        PreparedStatement stmt = null;
        ResultSet rs = null;

        String sql = "select p.*, c.*, t.* from cliente p, pessoajuridica c, tipopessoajuridica t where p.idcliente = c.idcliente and c.idtipopessoajuridica = t.idtipopessoajuridica;";

        try {
            stmt = conn.prepareStatement(sql);
            rs = stmt.executeQuery();

            while (rs.next()) {
                
                PessoaJuridica pessoajuridica = new PessoaJuridica();
                pessoajuridica.setIdCliente(rs.getInt("idcliente"));
                pessoajuridica.setNomeCliente(rs.getString("nomecliente"));
                pessoajuridica.setTelefoneCliente(rs.getDouble("telefonecliente"));
                pessoajuridica.setNomePessoaJuridica(rs.getString("nomepessoajuridica"));
                pessoajuridica.setCnpjPessoaJuridica(rs.getInt("cnpjpessoajuridica"));
                pessoajuridica.setIdCategoria(rs.getInt("idcategoria"));
                pessoajuridica.setTipoPessoaj(new Categoria(rs.getInt("idtipopessoajuridica")));
                pessoajuridica.setTipoPessoaj(new Categoria(rs.getString("nometipopessoajuridica")));
                
               
                pessoajuridicas.add(pessoajuridica);
            }

        } catch (SQLException ex) {
            System.out.println("Problema ao listar cliente: " + ex.getMessage());
            ex.printStackTrace();

        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt, rs);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
        return pessoajuridicas;
    }

    @Override
    public Boolean excluir(int idObject) {
        PreparedStatement stmt = null;
        String sql = "delete from pessoajuridica using cliente where pessoajuridica.idcliente = cliente.idcliente and cliente.idcliente = ?;";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idObject);
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problema ao excluir cliente: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
    }

    @Override
    public Object carregar(int idObject) {
        PreparedStatement stmt = null;
        ResultSet rs = null;
        Pessoaj pessoajuridica = new Pessoaj();

        String sql = "select p.*, c.* from cliente p, pessoajuridica c where p.idcliente = c.idcliente and c.idcliente = ?;";
        try {
            stmt = conn.prepareStatement(sql);
            stmt.setInt(1, idObject);
            rs = stmt.executeQuery();

            while (rs.next()) {
             
              
                pessoajuridica.setIdCliente(rs.getInt("idcliente"));
                pessoajuridica.setDescCliente(rs.getString("desccliente"));
                pessoajuridica.setMarcaCliente(rs.getString("marcacliente"));
                pessoajuridica.setModeloCliente(rs.getString("modelocliente"));
                pessoajuridica.setPrecoCliente(rs.getDouble("precocliente"));
                pessoajuridica.setAnoPessoaj(rs.getInt("anopessoajuridica"));
                pessoajuridica.setModeloPessoaj(rs.getInt("modelopessoajuridica"));
                pessoajuridica.setNrportaPessoaj(rs.getInt("nrportaspessoajuridica"));
                pessoajuridica.setIdPessoaj(rs.getInt("idpessoajuridica"));
                
            }
        } catch (SQLException ex) {
            System.out.println("Problema ao carregar cliente: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
        return pessoajuridica;
    }

    @Override
    public Boolean alterar(Object object) {

        Cliente cliente = (Cliente) object;
        PreparedStatement stmt = null;
        String sql = "update cliente set desccliente = ?, marcacliente = ?, modelocliente = ?, precocliente = ? where idcliente = ?;";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, cliente.getDescCliente());
            stmt.setString(2, cliente.getMarcaCliente());
            stmt.setString(3, cliente.getModeloCliente());
            stmt.setDouble(4, cliente.getPrecoCliente());
            stmt.setInt(5, cliente.getIdCliente());
            stmt.executeUpdate();
            return true;
        } catch (SQLException ex) {
            System.out.println("Problema ao alterar cliente: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception e) {
                System.out.println("Problemas ao fechar a conexão! Erro: " + e.getMessage());
                e.printStackTrace();
            }

        }
    }
}
