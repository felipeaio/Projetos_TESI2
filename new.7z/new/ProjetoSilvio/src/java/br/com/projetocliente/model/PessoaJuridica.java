
package br.com.projetocliente.model;

public class PessoaJuridica extends Cliente{
 private Integer idPessoaJuridica;
 private String nomePessoaJuridica;
 private Integer cnpjPessoaJuridica;
 private Integer idCategoria;


    public PessoaJuridica() {
    }

    public PessoaJuridica(Integer idPessoaJuridica, String nomePessoaJuridica, Integer cnpjPessoaJuridica, Integer idCategoria) {
        this.idPessoaJuridica = idPessoaJuridica;
        this.nomePessoaJuridica = nomePessoaJuridica;
        this.cnpjPessoaJuridica = cnpjPessoaJuridica;
        this.idCategoria = idCategoria;
    }

    public Integer getIdPessoaJuridica() {
        return idPessoaJuridica;
    }

    public void setIdPessoaJuridica(Integer idPessoaJuridica) {
        this.idPessoaJuridica = idPessoaJuridica;
    }

    public String getNomePessoaJuridica() {
        return nomePessoaJuridica;
    }

    public void setNomePessoaJuridica(String nomePessoaJuridica) {
        this.nomePessoaJuridica = nomePessoaJuridica;
    }

    public Integer getCnpjPessoaJuridica() {
        return cnpjPessoaJuridica;
    }

    public void setCnpjPessoaJuridica(Integer cnpjPessoaJuridica) {
        this.cnpjPessoaJuridica = cnpjPessoaJuridica;
    }

    public Integer getIdCategoria() {
        return idCategoria;
    }

    public void setIdCategoria(Integer idCategoria) {
        this.idCategoria = idCategoria;
    }




}
