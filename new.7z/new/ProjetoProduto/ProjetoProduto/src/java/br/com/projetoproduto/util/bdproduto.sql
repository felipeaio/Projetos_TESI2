/*
create table produto(
	idproduto serial not null,
	descproduto varchar(40),
 	marcaproduto varchar(40),
	modeloproduto varchar(40),
	precoproduto numeric(9,2),
	constraint pk_produto primary key(idproduto)
);

create table carro(
        idcarro serial not null,
	anocarro integer,
	modelocarro integer,
	nrportascarro integer,
	idproduto integer,
	idtipocarro integer,
	constraint pk_carro primary key (idcarro),
	constraint fk_carro_produto foreign key(idproduto) references produto(idproduto),
    constraint fk_carro_tipocarro foreign key(idtipocarro) references tipocarro(idtipocarro)
);


create table tipocarro(
    idtipocarro serial not null,
    nometipocarro varchar(30),
    constraint pk_tipocarro primary key(idtipocarro)
);
*/

--Cliente(id, nome, telefone)
--PessoaJuridica(id, nomefantasia, cnpj, idcategoria)
--Categoria(id, nomecategoria)


create table cliente(
	idcliente serial not null,
	nomecliente varchar(40),
	telefonecliente numeric(9,2),
	constraint pk_cliente primary key(idcliente)
);

create table pessoaj(
    idpessoaj serial not null,
	nomepessoaj varchar(40),
	cnpjpessoaj integer,
	idcategoria integer,
	idcliente integer,
	constraint pk_pessoaj primary key (idpessoaj),
	constraint fk_pessoaj_cliente foreign key(idcliente) references cliente(idcliente),
    constraint fk_pessoaj_categoria foreign key(idcategoria) references categoria(idcategoria)
);


create table categoria(
    idcategoria serial not null,
    nomecategoria varchar(30),
    constraint pk_categoria primary key(idcategoria)
);

drop table cliente;
drop table categoria;

