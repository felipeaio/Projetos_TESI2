create table proprietario(
	idproprietario serial not null,
	nomeproprietario varchar(40),
	categoriaproprietario varchar(40),
	statusproprietario varchar (10),
	cpfproprietario numeric(11),
	rgproprietario numeric(10),
	constraint pk_proprietario primary key(idproprietario)
);

select * from proprietario;