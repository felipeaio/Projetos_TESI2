package br.com.projetoproprietario.dao;

import br.com.projetoproprietario.util.ConnectionFactory;
import br.com.projetoproprietario.model.Proprietario;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class ProprietarioDAOImpl implements GenericDAO {

    private Connection conn;

    public ProprietarioDAOImpl() throws Exception {
        try {
            this.conn = ConnectionFactory.getConnection();
            System.out.println("Conectado com Sucesso!");
        } catch (Exception ex) {
            throw new Exception(ex.getMessage());
        }
    }

    @Override

    public Boolean cadastrar(Object object) {

        Proprietario proprietario = (Proprietario) object;
        PreparedStatement stmt = null;

        String sql = "insert into proprietario(nomeproprietario, categoriaproprietario, statusproprietario, cpfproprietario, rgproprietario) values (?, ?, ?, ?, ?);";

        try {
            stmt = conn.prepareStatement(sql);
            stmt.setString(1, proprietario.getNomeProprietario());
            stmt.setString(2, proprietario.getCategoriaProprietario());
            stmt.setString(3, proprietario.getStatusProprietario());
            stmt.setDouble(4, proprietario.getCpfProprietario());
            stmt.setDouble(4, proprietario.getRgProprietario());
            stmt.execute();
            return true;
        } catch (Exception ex) {
            System.out.println("Problemas ao cadastrar proprietario! Erro: " + ex.getMessage());
            ex.printStackTrace();
            return false;
        } finally {
            try {
                ConnectionFactory.closeConnection(conn, stmt);
            } catch (Exception ex) {
                System.out.println("Problemas ao fechar conexÃ£o! Erro" + ex.getMessage());
                ex.printStackTrace();
            }
        }

    }

    @Override
    public Boolean alterar(Object object) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public List<Object> listar() {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Boolean excluir(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

    @Override
    public Object carregar(int idObject) {
        throw new UnsupportedOperationException("Not supported yet."); //To change body of generated methods, choose Tools | Templates.
    }

}
