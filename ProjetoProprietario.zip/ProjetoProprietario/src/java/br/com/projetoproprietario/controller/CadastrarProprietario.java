package br.com.projetoproprietario.controller;

import br.com.projetoproprietario.dao.GenericDAO;
import br.com.projetoproprietario.dao.ProprietarioDAOImpl;
import br.com.projetoproprietario.model.Proprietario;
import java.io.IOException;
import java.io.PrintWriter;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet(name = "CadastrarProprietario", urlPatterns = {"/CadastrarProprietario"})
public class CadastrarProprietario extends HttpServlet {


    protected void processRequest(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        response.setContentType("text/html;charset=UTF-8");
        try (PrintWriter out = response.getWriter()) {
            
            String nomeProprietario = request.getParameter("nomeProprietario");
            String categoriaProprietario = request.getParameter("categoriaProprietario");
            String statusProprietario = request.getParameter("statusProprietario");
            Double cpfProprietario = Double.parseDouble(request.getParameter("cpfProprietario"));
            Double rgProprietario = Double.parseDouble(request.getParameter("rgProprietario"));

            
            String mensagem = null;
            
            Proprietario proprietario = new Proprietario();  
            proprietario.setNomeProprietario(nomeProprietario);
            proprietario.setCategoriaProprietario(categoriaProprietario);
            proprietario.setStatusProprietario(statusProprietario);
            proprietario.setCpfProprietario(cpfProprietario);
            proprietario.setRgProprietario(rgProprietario);
            
            try{
                GenericDAO dao = new ProprietarioDAOImpl();
                if (dao.cadastrar(proprietario)){
                mensagem = "Proprietario Cadastrado com Sucesso";
                }else{ 
                mensagem = "Problema ao cadastrar Proprietario. " + "Verifique os dados informados e tente novamente";
                }
                request.setAttribute("mensagem",mensagem);
                request.getRequestDispatcher("cadastrarproprietario.jsp").forward(request,response);
            }catch (Exception ex){
                System.out.println("PRoblemas na Servlet ao cadastrar proprietario! Erro: " + ex.getMessage());
                ex.printStackTrace();
            } 
            }        
        }
    

    // <editor-fold defaultstate="collapsed" desc="HttpServlet methods. Click on the + sign on the left to edit the code.">
    /**
     * Handles the HTTP <code>GET</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Handles the HTTP <code>POST</code> method.
     *
     * @param request servlet request
     * @param response servlet response
     * @throws ServletException if a servlet-specific error occurs
     * @throws IOException if an I/O error occurs
     */
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        processRequest(request, response);
    }

    /**
     * Returns a short description of the servlet.
     *
     * @return a String containing servlet description
     */
    @Override
    public String getServletInfo() {
        return "Short description";
    }// </editor-fold>

}
