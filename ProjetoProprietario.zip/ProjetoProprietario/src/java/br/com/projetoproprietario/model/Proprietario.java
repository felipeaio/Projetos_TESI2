package br.com.projetoproprietario.model;

public class Proprietario {

 private Integer idProprietario;
 private String nomeProprietario;
 private String categoriaProprietario;
 private String statusProprietario;
 private Double cpfProprietario;
 private Double rgProprietario;

    public Proprietario() {
    }

    public Proprietario(Integer idProprietario, String nomeProprietario, String categoriaProprietario, String statusProprietario, Double cpfProprietario, Double rgProprietario) {
        this.idProprietario = idProprietario;
        this.nomeProprietario = nomeProprietario;
        this.categoriaProprietario = categoriaProprietario;
        this.statusProprietario = statusProprietario;
        this.cpfProprietario = cpfProprietario;
        this.rgProprietario = rgProprietario;
    }

    public Integer getIdProprietario() {
        return idProprietario;
    }

    public void setIdProprietario(Integer idProprietario) {
        this.idProprietario = idProprietario;
    }

    public String getNomeProprietario() {
        return nomeProprietario;
    }

    public void setNomeProprietario(String nomeProprietario) {
        this.nomeProprietario = nomeProprietario;
    }

    public String getCategoriaProprietario() {
        return categoriaProprietario;
    }

    public void setCategoriaProprietario(String categoriaProprietario) {
        this.categoriaProprietario = categoriaProprietario;
    }

    public String getStatusProprietario() {
        return statusProprietario;
    }

    public void setStatusProprietario(String statusProprietario) {
        this.statusProprietario = statusProprietario;
    }

    public Double getCpfProprietario() {
        return cpfProprietario;
    }

    public void setCpfProprietario(Double cpfProprietario) {
        this.cpfProprietario = cpfProprietario;
    }

    public Double getRgProprietario() {
        return rgProprietario;
    }

    public void setRgProprietario(Double rgProprietario) {
        this.rgProprietario = rgProprietario;
    }
}

